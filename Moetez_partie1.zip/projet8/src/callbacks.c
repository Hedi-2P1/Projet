#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "client.h"
#include "sms.h"
#include "sendMail.h"
client p1;
char Av[30];
int check_genre,testemail,testsms,supp,check_modif;


void
on_checkbutton_supp_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
supp=1;

}

void
on_button_va_modif_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *input_cin,*input_nom,*input_prenom,*input_montant,*input_jour,*input_mois,*input_annee
,*input_achat,*input_vente,*input_homme,*input_femme,window;
int jour,mois,annee;
  window1 = create_window_modif_tree_cl ();
input_cin=lookup_widget(window1,"entry_modif_cin_cl");
input_nom=lookup_widget(window1,"entry_modif_nom_cl");
input_prenom=lookup_widget(window1,"entry_modif_prenom_cl");
input_montant=lookup_widget(window1,"entry_modif_montant_cl");
input_jour=lookup_widget(window1,"spinbutton_modif_jour_cl");
input_mois=lookup_widget(window1,"spinbutton_modif_mois_cl");
input_annee=lookup_widget(window1,"spinbutton_modif_annee_cl");
input_achat=lookup_widget(window1,"checkbutton_modif_achat_cl");
input_vente=lookup_widget(window1,"checkbutton_modif_vente_cl");
input_homme=lookup_widget(window1,"radiobutton_modif_homme_cl");
input_femme=lookup_widget(window1,"radiobutton_modif_femme_cl");

gtk_entry_set_text(GTK_ENTRY(input_cin),p1.cin);
gtk_entry_set_text(GTK_ENTRY(input_nom),p1.nom);
gtk_entry_set_text(GTK_ENTRY(input_prenom),p1.prenom);
gtk_entry_set_text(GTK_ENTRY(input_montant),p1.montant);


sscanf(p1.date_naissance,"%d/%d/%d",&jour,&mois,&annee);

gtk_spin_button_set_value(GTK_SPIN_BUTTON(input_jour),jour);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input_mois),mois);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input_annee),annee);


if (strcmp(p1.type,"achat")==0)
gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (input_achat), TRUE);
else   gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (input_vente), TRUE);

if (strcmp(p1.genre,"homme")==0)
gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (input_homme), TRUE);
else gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (input_vente), TRUE);

gtk_widget_show (window1);
}




void
on_checkbutton_edit_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
supp=0;
}

void
on_afficher_cl_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;

fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
fenetre_afficher=create_fenetre_afficher_cl();
gtk_widget_show(fenetre_afficher);


treeview1=lookup_widget(fenetre_afficher,"treeview_princ_cl");

afficher_client(treeview1);


}


void
on_ajout_cl_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
  window1 = create_fenetre_ajout_cl ();
  gtk_widget_show (window1);

}


void
on_button_modification_cl_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
  window1 = create_Modification_cl ();
  gtk_widget_show (window1);

}


void
on_button_recherche_cl_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
GtkWidget *input_cin;
char cin[50];
input_cin=lookup_widget(objet,"entry7_cl");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input_cin)));

fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
fenetre_afficher=create_fenetre_afficher_cl();
gtk_widget_show(fenetre_afficher);


treeview1=lookup_widget(fenetre_afficher,"treeview_princ_cl");

recherche(treeview1,cin);

}


void
on_radiobutton_homme_cl_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
check_genre=1;
else 
check_genre=2;

}


void
on_radiobutton_femme_cl_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
check_genre=2;
else 
check_genre=1;

}


void
on_checkbutton_vente_cl_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(Av,"vente");

}


void
on_checkbutton_mail_cl_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
testemail=1;
else
testemail=0;

}


void
on_checkbutton_sms_cl_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
testsms=1;
else
testsms=0;

}


void
on_checkbutton_achat_cl_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(Av,"achat");

}


void
on_ajouter_cl_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
client p;

GtkWidget *input_cin, *input_nom, *input_prenom, *input_montant,*input_j,*input_m,*input_a,*input_sms,*input_email;
GtkWidget *test;
GtkWidget *fenetre_ajout;
GtkWidget *at_thing;
int J,M,A;
char sms[20],email[50],G[50],finalsms[20];
char finalemail[100],at[15],date[30];

fenetre_ajout=lookup_widget(objet,"fenetre_ajout");

at_thing=lookup_widget(objet,"entry_at_cl");
input_cin=lookup_widget(objet,"entry_cin_cl");
input_nom=lookup_widget(objet,"entry_nom_cl");
input_prenom=lookup_widget(objet,"entry_prenom_cl");
input_montant=lookup_widget(objet,"entry_montant");
input_j=lookup_widget(objet,"spinbutton_j_cl");
input_m=lookup_widget(objet,"spinbutton_m_cl");
input_a=lookup_widget(objet,"spinbutton_a_cl");
input_sms=lookup_widget(objet,"entry_email_cl");
input_email=lookup_widget(objet,"entry_sms_cl");
test=lookup_widget(objet,"label_test");
J=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_j));
M=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_m));
A=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_a));
if (check_genre==1) strcpy(G,"homme");
if (check_genre==2) strcpy(G,"femme");
sprintf(date,"%d/%d/%d",J,M,A);

if (testsms==1){
strcpy(sms,gtk_entry_get_text(GTK_ENTRY(input_email)));
sprintf(finalsms,"+216%s",sms);
gtk_label_set_text(test,finalsms);
sendSms(finalsms);}
if (testemail==1){
strcpy(email,gtk_entry_get_text(GTK_ENTRY(input_sms)));
strcpy(at,gtk_entry_get_text(GTK_ENTRY(at_thing)));
sprintf(finalemail,"%s@%s",email,at);
sendMail(finalemail);
}
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input_cin)));
strcpy(p.genre,G);
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input_nom)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input_prenom)));
strcpy(p.date_naissance,date);
strcpy(p.type,Av);
strcpy(p.montant,gtk_entry_get_text(GTK_ENTRY(input_montant)));
ajouter_client(p);

}


void
on_button4_cl_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
char cin[50],mod[50],critere[50];
GtkWidget *input_cin,*input_mod,*combo;
input_cin=lookup_widget(objet,"entry8_cl");
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input_cin)));
input_mod=lookup_widget(objet,"entry_amodifier_cl");
strcpy(mod,gtk_entry_get_text(GTK_ENTRY(input_mod)));
combo=lookup_widget(objet,"comboboxentry_critere_cl");
strcpy(critere,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combo)));
modification (mod,critere,cin);

}


void
on_treeview_princ_cl_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
if (supp==1){
        GtkTreeIter iter;
        gchar* nom;
        gchar* prenom;
        gchar* date;
        gchar* type;
        gchar* cin;
 gchar* montant;
gchar* genre;
        client p;

        GtkTreeModel *model = gtk_tree_view_get_model(treeview);
         if (gtk_tree_model_get_iter(model, &iter ,path))
        {

                gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &cin, 1,  &nom, 2, &prenom ,3, &date,4,&type,5,&montant,6,&genre,-1);

                strcpy(p.cin,cin);
                strcpy(p.nom,nom);
                strcpy(p.prenom,prenom);
                strcpy(p.date_naissance,date);
                strcpy(p.type,type);
                strcpy(p.montant,montant);
                strcpy(p.genre,genre);
                supprimer_client(p);
                afficher_client(treeview);
        }
}


}


void
on_treeview_princ_cl_row_activated2    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
        gchar* nom;
        gchar* prenom;
        gchar* date;
        gchar* type;
        gchar* cin;
 gchar* montant;
gchar* genre;

        GtkTreeModel *model = gtk_tree_view_get_model(treeview);
        if (gtk_tree_model_get_iter(model, &iter ,path))
        {

                gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &cin, 1,  &nom, 2, &prenom ,3, &date,4,&type,5,&montant,6,&genre,-1);

                strcpy(p1.cin,cin);
                strcpy(p1.nom,nom);
                strcpy(p1.prenom,prenom);
                strcpy(p1.date_naissance,date);
                strcpy(p1.type,type);
                strcpy(p1.montant,montant);
                strcpy(p1.genre,genre);
}
}


void
on_radiobutton_modif_homme_cl_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))

check_modif=1;
}


void
on_radiobutton_modif_femme_cl_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))

check_modif=2;
}


void
on_checkbutton_modif_achat_cl_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(Av,"achat");

}


void
on_checkbutton_modif_vente_cl_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(Av,"vente");

}


void
on_button_modif_tree_cl_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
client p;

GtkWidget *input_cin, *input_nom, *input_prenom, *input_montant,*input_j,*input_m
,*input_a,*input_achat,*input_vente,*input_homme,*input_femme;
int jour,mois,annee;
char date[50],retour[50],finalsms[20];
input_cin=lookup_widget(objet,"entry_modif_cin_cl");
input_nom=lookup_widget(objet,"entry_modif_nom_cl");
input_prenom=lookup_widget(objet,"entry_modif_prenom_cl");
input_montant=lookup_widget(objet,"entry_modif_montant_cl");
input_j=lookup_widget(objet,"spinbutton_modif_jour_cl");
input_m=lookup_widget(objet,"spinbutton_modif_mois_cl");
input_a=lookup_widget(objet,"spinbutton_modif_annee_cl");
input_achat=lookup_widget(objet,"checkbutton_modif_achat_cl");
input_vente=lookup_widget(objet,"checkbutton_modif_vente_cl");
input_homme=lookup_widget(objet,"radiobutton_modif_homme_cl");
input_femme=lookup_widget(objet,"radiobutton_modif_femme_cl");

jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_j));
mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_m));
annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input_a));
strcpy(retour,"");

if (check_modif==1) {strcpy(retour,"homme");}
if (check_modif==2) {strcpy(retour,"femme");}

sprintf(date,"%d/%d/%d",jour,mois,annee);
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input_cin)));
strcpy(p.genre,retour);
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input_nom)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input_prenom)));
strcpy(p.date_naissance,date);
strcpy(p.type,Av);
strcpy(p.montant,gtk_entry_get_text(GTK_ENTRY(input_montant)));
modif_client(p1.cin,p);


}


void
on_button_rech_cl_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_recherche,*input1;
fenetre_recherche=create_Rechercher_cl();
gtk_widget_show(fenetre_recherche);

}

