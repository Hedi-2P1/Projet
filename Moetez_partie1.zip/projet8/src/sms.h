void sendSms(char reciever[20]);
