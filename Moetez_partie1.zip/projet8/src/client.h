#include<gtk/gtk.h>


typedef struct 
{
char cin[30];
char nom[30];
char prenom[30];
char date_naissance[30];
char type[30];
char montant[30];
char genre[30];
}client;

void ajouter_client(client p);
void afficher_client(GtkWidget *liste);
void supprimer_client(client p);
void modif_client (char cin[30],client p);
void modification (char achanger[50],char critere[50],char cin[50]);
void recherche(GtkWidget *liste,char id[50]);

