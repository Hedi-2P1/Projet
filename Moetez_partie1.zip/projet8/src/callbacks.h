#include <gtk/gtk.h>


void
on_button2_Ajout_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_vente_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button4_modification_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button3_recherche_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_recherche_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sms_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_mail_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_supp_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_modif_tree_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_checkbutton_modif_achat_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton_modif_vente_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_modif_homme_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modif_femme_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_va_modif_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated2            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton_modif_femme_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_edit_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_retour_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_cl_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajout_cl_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modification_cl_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_recherche_cl_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton_homme_cl_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_cl_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_vente_cl_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_mail_cl_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_sms_cl_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_achat_cl_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajouter_cl_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button4_cl_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_princ_cl_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_treeview_princ_cl_row_activated2    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_radiobutton_modif_homme_cl_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modif_femme_cl_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_modif_achat_cl_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton_modif_vente_cl_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_modif_tree_cl_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_rech_cl_clicked              (GtkButton       *button,
                                        gpointer         user_data);
