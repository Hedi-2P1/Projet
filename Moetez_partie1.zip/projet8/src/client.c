#ifdef HAVE_CONFIG_H
#include <config.h>
#endif



#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"client.h"
#include<gtk/gtk.h>

enum
{ 
	ECIN,
	ENOM,
	EPRENOM,
	EDATE,
	ETYPE,
	EMONTANT,
	EGENRE,
	COLUMNS,
};
///////////////////////////////////////////////
void ajouter_client(client p)
{
FILE *f;
f = fopen("client.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %s %s \n",p.cin,p.nom,p.prenom,p.date_naissance,p.type,p.montant,p.genre);
fclose(f);
}}
///////////////////////////////////////////////
void afficher_client(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	char cin[30],nom[30],prenom[30],date[30],type[30],montant[30],genre[30];
	store=NULL;
	FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",ECIN,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",EPRENOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);  

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("date", renderer, "text",EDATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	  renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("montant", renderer, "text",EMONTANT,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("type", renderer, "text",ETYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	 renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("genre", renderer, "text",EGENRE,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 
	}

	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("client.txt","r+");
	if(f==NULL)
	{
		return;
	}
	else
	{f= fopen("client.txt","r");
		while(fscanf(f,"%s %s %s %s %s %s %s \n",cin,nom,prenom,date,type,montant,genre)!=EOF)
		{
			gtk_list_store_append(store, &iter);
			gtk_list_store_set(store,&iter, ECIN, cin, ENOM, nom, 	EPRENOM,prenom,EDATE,date,ETYPE,type,EMONTANT,montant,EGENRE,genre, -1);
		}
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}





}
///////////////////////////////////////////////
void supprimer_client(client p)
///////////////////////////////////////////////
{
client p2;
FILE *f,*g;
	f=fopen("client.txt","r");
	g=fopen("temp.txt","w");
	if( f==NULL  || g==NULL )
		return;
	else
	{
		while(fscanf(f,"%s %s %s %s %s %s %s \n",p2.cin,p2.nom,p2.prenom,p2.date_naissance,p2.type,p2.montant,p2.genre)!=EOF)
		{
			if (strcmp(p.cin,p2.cin)!=0 || strcmp(p.nom,p2.nom)!=0 || strcmp(p.prenom,p2.prenom)!=0 || strcmp(p.date_naissance,p2.date_naissance)!=0 || strcmp(p.type,p2.type)!=0|| strcmp(p.montant,p2.montant)!=0|| strcmp(p.genre,p2.genre)!=0)
			fprintf(g,"%s %s %s %s %s %s %s \n",p2.cin,p2.nom,p2.prenom,p2.date_naissance,p2.type,p2.montant,p2.genre);
		}
		fclose(f);
		fclose(g);
remove("client.txt");
rename("temp.txt","client.txt");
	}
}


void modification (char changement[50],char test[50],char id[50]){      
client p1;
FILE *fp, *temp;
temp=fopen ("temp.txt","a");
fp=fopen ("client.txt","r+");
while (fscanf(fp,"%s %s %s %s %s %s %s\n",p1.cin,p1.nom,
p1.prenom,p1.date_naissance,
p1.type,p1.montant,p1.genre)!=EOF)
{
if (strcmp(p1.cin,id)==0){
if(strcmp(test,"cin")==0)   
{       
strcpy(p1.cin,changement);}
if(strcmp(test,"nom")==0)    
{      
strcpy(p1.nom,changement);     }
if(strcmp(test,"prenom")==0)    
{       
strcpy(p1.prenom,changement);     }
if(strcmp(test,"date")==0)    
{      
   strcpy(p1.date_naissance,changement);}     
if(strcmp(test,"type")==0)    
{    strcpy(p1.type,changement);     }
if(strcmp(test,"montant")==0)    
{      strcpy(p1.montant,changement);    } 
}
if(strcmp(test,"genre")==0)    
{      strcpy(p1.genre,changement);    } 

fprintf(temp,"%s %s %s %s %s %s %s\n",p1.cin,p1.nom,p1.prenom,p1.date_naissance,p1.type,p1.montant,p1.genre);
}
fclose(temp);
fclose(fp);
remove ("client.txt");
rename ("temp.txt","client.txt");
}


void recherche(GtkWidget *liste,char id[50])
{
        GtkCellRenderer *renderer;
        GtkTreeViewColumn *column;
        GtkTreeIter iter;
        GtkListStore *store;
        char cin[30],nom[30],prenom[30],date[30],type[30],montant[30],genre[30];
        store=NULL;
        FILE *f;
        store=gtk_tree_view_get_model(liste);

        if (store==NULL)
        {
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("cin", renderer, "text",ECIN,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",ENOM,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",EPRENOM,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);  

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("date", renderer, "text",EDATE,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

          renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("montant", renderer, "text",EMONTANT,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column); 

       renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("type", renderer, "text",ETYPE,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("genre", renderer, "text",EGENRE,NULL);
        gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);


	}
        store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,  G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
        f=fopen("client.txt","r");
        if(f==NULL)
        {
                return 0;
        }
        else
        {
                f= fopen("client.txt","a+");
                while(fscanf(f,"%s %s %s %s %s %s %s \n",cin,nom,prenom,date,type,montant,genre)!=EOF){if(strcmp(id,cin)==0){
                        gtk_list_store_append(store, &iter);
                        gtk_list_store_set(store,&iter, ECIN, cin, ENOM, nom,   EPRENOM,prenom,EDATE,date,ETYPE,type,EMONTANT,montant,EGENRE,genre,-1);

                }}
                fclose(f);
                gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
                g_object_unref (store);
        }


}

/**/
void modif_client (char cin[50],client p){ 
client p1;
FILE *fp, *temp;
temp=fopen ("temp.txt","a");
fp=fopen ("client.txt","r+");
while (fscanf(fp,"%s %s %s %s %s %s %s\n",p1.cin,p1.nom,p1.prenom,p1.date_naissance,p1.type,p1.montant,p1.genre)!=EOF)
{
if (strcmp(cin,p1.cin)==0){fprintf(temp,"%s %s %s %s %s %s %s\n",p.cin,p.nom,p.prenom,p.date_naissance,p.type,p.montant,p.genre);

}
else 
fprintf(temp,"%s %s %s %s %s %s %s\n",p1.cin,p1.nom,p1.prenom,p1.date_naissance,p1.type,p1.montant,p1.genre);
}
fclose(temp);
fclose(fp);
remove ("client.txt");
rename ("temp.txt","client.txt");
}

