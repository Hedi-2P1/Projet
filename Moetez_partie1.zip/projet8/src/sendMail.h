void sendMail(char mail[100]);
