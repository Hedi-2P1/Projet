#include <curl/curl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sms.h"
void sendSms(char reciever[20])
{
  CURLcode ret;
  CURL *hnd;
  struct curl_slist *slist1;
char instruct[300];
char message[100];
strcpy(message,"Bienvenue a smart farm!");
sprintf(instruct,"{\"outboundSMSMessageRequest\":{\n        \"address\": \"tel:%s\",\n        \"senderAddress\":\"tel:+21655602457\",\n        \"outboundSMSTextMessage\":{\n            \"message\": \"%s\"\n        }\n    }\n}",reciever,message);
  slist1 = NULL;
  slist1 = curl_slist_append(slist1, "Authorization: Bearer itco3WtrYKSyA9HRouzgfwvjAFGm");
  slist1 = curl_slist_append(slist1, "Content-Type: application/json");

  hnd = curl_easy_init();
  curl_easy_setopt(hnd, CURLOPT_BUFFERSIZE, 102400L);
  curl_easy_setopt(hnd, CURLOPT_URL, "https://api.orange.com/smsmessaging/v1/outbound/tel%3A%2B21655602457/requests");
  curl_easy_setopt(hnd, CURLOPT_NOPROGRESS, 1L);
  curl_easy_setopt(hnd, CURLOPT_POSTFIELDS, instruct);
  curl_easy_setopt(hnd, CURLOPT_POSTFIELDSIZE_LARGE, (curl_off_t)215);
  curl_easy_setopt(hnd, CURLOPT_HTTPHEADER, slist1);
  curl_easy_setopt(hnd, CURLOPT_USERAGENT, "curl/7.58.0");
  curl_easy_setopt(hnd, CURLOPT_MAXREDIRS, 50L);
  curl_easy_setopt(hnd, CURLOPT_HTTP_VERSION, (long)CURL_HTTP_VERSION_2TLS);
  curl_easy_setopt(hnd, CURLOPT_CUSTOMREQUEST, "POST");
  curl_easy_setopt(hnd, CURLOPT_FTP_SKIP_PASV_IP, 1L);
  curl_easy_setopt(hnd, CURLOPT_TCP_KEEPALIVE, 1L);

 
  ret = curl_easy_perform(hnd);

  curl_easy_cleanup(hnd);
  hnd = NULL;
  curl_slist_free_all(slist1);
  slist1 = NULL;

}

