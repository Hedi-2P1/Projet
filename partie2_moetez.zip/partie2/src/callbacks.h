#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);
