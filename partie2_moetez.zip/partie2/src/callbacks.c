#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "Meilleur.h"

void
on_button1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{int annee;
char sannee[50];
char retour[200];
GtkWidget *input1,*sortie;
input1=lookup_widget(objet,"entry1");
strcpy(sannee,gtk_entry_get_text(GTK_ENTRY(input1)));
annee=atoi(sannee);
sortie=lookup_widget(objet,"label3");
Meilleur(annee,retour);
gtk_label_set_text(GTK_LABEL(sortie),retour);


}

