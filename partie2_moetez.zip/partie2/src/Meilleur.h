void Meilleur (int annee,char c[200]);
int existe(char t[50][50],int n,char s[50]);

