#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Meilleur.h"
int existe(char t[50][50],int n,char s[50])
{int test=0;
for (int i=0;i<n;i++){
if (strcmp(t[i],s)==0){test=1;}
}
return test;
}

void Meilleur (int annee,char c[200]){
int temp1,temp2,temp3,v,max,pos;
int t[30];
char iden[50][50];
char ids[30];
int h;
char id[20];
h=0;
FILE *fl;
FILE *fp;
fl=fopen ("absenteisme.txt","r+");
while (fscanf(fl,"%s %d %d %d %d \n",id,&temp1,&temp2,&temp3,&v)!=EOF)
{sprintf(ids,"%s",id);
if (existe(iden,h,ids)==0){
strcpy(iden[h],ids);
h++;
}
}



fclose(fl);
for (int i=0;i<h;i++) {
t[i]=0;}
for (int i=0;i<h;i++){
fp=fopen ("absenteisme.txt","r+");
while (fscanf(fp,"%s %d %d %d %d \n",id,&temp1,&temp2,&temp3,&v)!=EOF)
{
if ((v==1)&&(annee==temp3)&&(strcmp(id,iden[i])==0) ){
t[i]++;
}
}
}
fclose(fp);
max=t[0];
pos=0;
int i;
for (i=0;i<h;i++){
if (t[i]>max){
max=t[i];
pos=i;
}
}
sprintf(c,"L'employe d'identifiant %s \nest le meilleur employe de lannee %d \navec %d jours de travails",iden[pos],annee,max);
printf("%s",c);
}

