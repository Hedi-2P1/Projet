#include <gtk/gtk.h>



void
on_button_aff_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

