
#include <gtk/gtk.h>

typedef struct
{char type[30];
char race[30];
char matricule[15];
char etat[30];
char poids[10];
char genre[10];
}troupeau;




int calcul(char type[]);
